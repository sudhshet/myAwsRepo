import subprocess
import argparse, time
import os,sys
import ipaddress

def shell_run_cmd(cmd):
    print(cmd)
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,encoding="utf-8")
    stdout, stderr = p.communicate()
    retCode = p.returncode
    stdout= stdout.strip()
    print("stdout:" + str(stdout.split("\n")) + " stderr: " + stderr + " retCode: " + str(retCode))
    return (stdout, retCode)         

def main():
    parser = argparse.ArgumentParser(
            description='route addition for secondary interface'
           )
    parser.add_argument( '--secondaryIFPeers', required=True, default=None,help='Secondary interface neighbors (comma separated)')
    args = parser.parse_args()
    secondaryENIPeers=args.secondaryIFPeers.split(',')
    intf="eth1"
    cmd="ip a |grep " + intf + " |grep 'scope global' |cut -d ' ' -f 6"
    network, retCode=shell_run_cmd(cmd)
    if retCode == 0:
        ipNet =ipaddress.ip_network(network, strict=False)
        gw = str(ipNet[1])           
        for secPeer in secondaryENIPeers:
            shell_run_cmd("sudo ip r add " + secPeer + " dev " + intf + " via " + gw )
    else:
        print("Error in getting ip address!! exiting")    
        exit(1)
if __name__ == "__main__":
    main()