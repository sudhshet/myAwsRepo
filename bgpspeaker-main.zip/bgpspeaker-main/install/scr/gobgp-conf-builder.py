import json
import argparse, time
from logging import exception
import os,sys
import ipaddress
import traceback
from datetime import datetime

def buildNeighbors(neighbors,authPassword,peerAS,primaryENIPeers,secondaryENIPeers):
    connectretry=int(os.environ.get('connect-retry', 1))
    holdtime=int(os.environ.get('hold-time', 6))
    keepaliveinterval=int(os.environ.get('keepalive-interval', 2))
    multihopHops=int(os.environ.get('multihopHops', 1))

    configAfiSafi=[{"config" : {"afi-safi-name": "ipv4-unicast"}}]
    timerConfig={"connect-retry": connectretry,"hold-time": holdtime,"keepalive-interval": keepaliveinterval}
    timer={}
    timer["config"]=timerConfig
    multihop={}
    multiHopConfig={"enabled": True, "multihop-ttl": multihopHops}
    multihop={}
    multihop["config"]=multiHopConfig
            
    peers = primaryENIPeers
    if secondaryENIPeers:
        peers.extend(secondaryENIPeers)
    for peer in peers:
        neighbor={"afi-safis": configAfiSafi}
        config={}
        if authPassword:
            config["auth-password"]=authPassword
        config["neighbor-address"]=peer
        config["peer-as"]=peerAS
        neighbor["config"]=config
        neighbor["timers"]=timer
        if multihopHops != 1:
            neighbor["ebgp-multihop"]=multihop
        neighbors.append(neighbor)
    return neighbors

def main():
    parser = argparse.ArgumentParser(
            description='BGP Gateway to translate BGP updates to AWS VPC route table changed '
           )
    parser.add_argument( '--primaryIFIP', required=True, help='Primary interface IP address')
    parser.add_argument( '--secondaryIFIP', required=False, default=None,help='Secondary interface IP address')
    parser.add_argument( '--bgpSpeakerAS', required=True, help='BGP Speaker AS Number')
#    parser.add_argument( '--peerASList', required=True, help='Comma separated Neighbor AS number list')
    parser.add_argument( '--peerAS', required=True, help='Peer AS Number')
    parser.add_argument( '--primaryIFPeers', required=True, help='Secondary interface neighbors (comma separated)')
    parser.add_argument( '--secondaryIFPeers', required=False, default=None,help='Secondary interface neighbors (comma separated)')
    parser.add_argument( '--authPassword', required=False, default=None,help='BGP Auth password (if any)')
    args = parser.parse_args()
    primaryENIIPAddress=args.primaryIFIP
    secondaryENIIPAddresses=None
    if args.secondaryIFIP:
        secondaryENIIPAddresses=args.secondaryIFIP
    bGPSpeakerAS=int(args.bgpSpeakerAS)
    peerAS=int(args.peerAS)
    primaryENIPeers=args.primaryIFPeers.split(',')
    secondaryENIPeers=None
    if args.secondaryIFPeers:
        secondaryENIPeers=args.secondaryIFPeers.split(',')
    authPassword=None
    if args.authPassword:
       authPassword=args.authPassword
    #primaryENIIPAddress=sys.argv[1]
    #secondaryENIIPAddresses=sys.argv[2]
    #bGPSpeakerAS=int(sys.argv[3])
    #peerAS=int(sys.argv[4])
    #primaryENIPeers=sys.argv[5].split(',')
    #secondaryENIPeers=sys.argv[6].split(',')
    #authPassword=None
    #if len(sys.argv)> 7:
    #        authPassword=sys.argv[7]
    conf={}    
    globalConf={}
    neighbors=[]

    config={}
    config["as"]=bGPSpeakerAS
    config["router-id"]=primaryENIIPAddress

    globalConf["config"]=config
    conf["global"]=globalConf
    localAddressList=[primaryENIIPAddress]
    
    if secondaryENIIPAddresses:
        localAddressList.append(secondaryENIIPAddresses)
    config["local-address-list"]=localAddressList
    conf["neighbors"]=neighbors

    conf["neighbors"] = buildNeighbors(neighbors,authPassword,peerAS,primaryENIPeers,secondaryENIPeers)

    json_data = json.dumps(conf,indent=4)
    print(json_data)

    with open("/tmp/config.json", 'w') as outfile:
        json.dump(conf, outfile,indent=4)    
if __name__ == "__main__":
    main()