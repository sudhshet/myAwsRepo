#!/usr/bin/env python3

from __future__ import absolute_import
from __future__ import print_function

import requests, signal
import argparse, time
import botocore, boto3
import json
import ipaddress
import os
import sys, datetime
import logging
#from ec2_metadata import ec2_metadata
from threading import Timer
from requests.packages.urllib3 import Retry
import subprocess,copy,time
from multiprocessing import Process

import grpc
from google.protobuf.any_pb2 import Any
from google.protobuf.json_format import MessageToDict

import gobgp_pb2
import gobgp_pb2_grpc
import attribute_pb2

_TIMEOUT_SECONDS = 1000000

homeDir=None
prefixDelegateFile=None
lgwRouteFile=None
gobgpConfFile=None
gobgpdFile=None
gobgpFile=None
LogsDir=None

client=None
rtbResources={}
subnetDetails={}
loopbackAdjustedCidr={}
publicPoolDetails={}
vpcId=[]
eni_table = {}
floatingPeerSecondaryIPs=[]
vpcRTTag=None
mainRT=None
#breakout=None
breakoutGWId=None
cacheUpdating=False
bgpUpdatesOngoing=False
SubnetLoopbacks=False

class RepeatTimer(Timer):
    def run(self):
        global bgpUpdatesOngoing
        while not self.finished.wait(self.interval):
            tprint("Entry: periodic Thread to rebuild to the data afresh")
            if bgpUpdatesOngoing == False:
                self.function(*self.args, **self.kwargs)
            else:
                tprint("BGP updates ongoing! skipping the cache update")    
            tprint("Exit: periodic Thread to rebuild to the data afresh")

## Logs are printed with timestamp as an output for kubectl logs of this container 
def tprint(var):
    global logger
    print (datetime.datetime.now(),"-",var)
    logger.info(var)
def setVars():
    ##Data from upstream
    global homeDir,prefixDelegateFile,lgwRouteFile,gobgpConfFile,gobgpdFile,gobgpFile,LogsDir
    homeDir="/home/ec2-user/"
    if not os.path.isdir(homeDir):
        homeDir="/app/"
    prefixDelegateFile=homeDir+"conf/prefix-delegation.json"
    lgwRouteFile=homeDir+"conf/service-2.json"
    gobgpConfFile=homeDir+"conf/config.json"
    gobgpdFile=homeDir+"bin/gobgpd"
    gobgpFile=homeDir+"bin/gobgp"
    LogsDir=homeDir+"logs/"
    ## data from upstream
def init(args):  
    global region
    global client
    #global breakout
    global breakoutGWId
    global vpcRTTag
    global SubnetLoopbacks
    global floatingPeerSecondaryIPs

    #breakout=args.breakout
    breakoutGWId=args.breakoutGWId    
    vpcRTTag=args.vpcRTTag
    if args.subnetLoopbacks == "True" or args.subnetLoopbacks == "true" :
        SubnetLoopbacks=True
    secIPs=os.environ.get('FloatingPeerSecondaryIPs',None)
    if secIPs:
        floatingPeerSecondaryIPs=secIPs.split(',')    
        tprint(f"FloatingPeerSecondaryIPs: {str(floatingPeerSecondaryIPs)}")
    tprint("vpcs: " + str(vpcId))

    client = boto3.client('ec2',region_name=region)
    #bgp_resource = boto3.resource('ec2',region_name=region)    
    build()
    tprint("Subnets: " + str(subnetDetails))
    tprint("Route Tables: " +str(rtbResources.keys()))
    tprint("public UE pool Cidrs: " + str(publicPoolDetails))

def build():
    global region
    global client
    global rtbResources
    global cacheUpdating
    cacheUpdating=True
    try:
        build_subnet_data()
        build_vpc_rt_data()
        build_publicPool_data()
        for rtb in rtbResources:
            if rtbResources[rtb] == None:
                tprint("Adding EC2 boto3 resource for RT: "+ rtb)
                rtbResources[rtb]= boto3.resource('ec2',region_name=region)   
    except Exception as e:
        tprint("Execption: caught exception " + str(e))
    cacheUpdating=False

def shell_run_cmd(cmd):
    tprint(cmd)
    p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,encoding="utf-8")
    stdout, stderr = p.communicate()
    retCode = p.returncode
    stdout= stdout.strip()
    tprint("stdout:" + str(stdout.split("\n")) + " stderr: " + stderr + " retCode: " + str(retCode))
    return (stdout, retCode)         
## This function gets the metadata token
def get_metadata_token():
    token_url="http://169.254.169.254/latest/api/token"
    headers = {'X-aws-ec2-metadata-token-ttl-seconds': '21600'}
    r= requests.put(token_url,headers=headers,timeout=(2, 5))
    return r.text

def get_info():
    global region,vpcId   
    headers = None

    instance_identity_url = "http://169.254.169.254/latest/dynamic/instance-identity/document"
    session = requests.Session()
    retries = Retry(total=3, backoff_factor=0.3)
    metadata_adapter = requests.adapters.HTTPAdapter(max_retries=retries)
    session.mount("http://169.254.169.254/", metadata_adapter)
    try:
        r = requests.get(instance_identity_url, timeout=(2, 5))
        code=r.status_code
        if code == 401: ###This node has IMDSv2 enabled, hence unauthorzied, we need to get token first and use the token
            tprint("node has IMDSv2 enabled!! Fetching Token first")
            token=get_metadata_token()
            headers = {'X-aws-ec2-metadata-token': token}
            r = requests.get(instance_identity_url, headers=headers, timeout=(2, 5))
            code=r.status_code
        if code == 200:
            response_json = r.json()
            region = response_json.get("region")
            macs_url="http://169.254.169.254/latest/meta-data/network/interfaces/macs/"
            r = requests.get(macs_url, headers=headers, timeout=(2,5))
            code=r.status_code            
            if code == 200:
                response = r.text
                macs=r.text.split('\n')
                for mac in macs:
                    r = requests.get(macs_url+mac+"vpc-id", headers=headers, timeout=(2,5))
                    code=r.status_code            
                    if code == 200:     
                        vpc = r.text    
                        if vpc not in vpcId:
                            vpcId.append(vpc)
            else:
                tprint("Got error while executing " + macs_url)
    except (requests.exceptions.ConnectTimeout, requests.exceptions.ConnectionError) as err:
        tprint("Exception: Connection to AWS EC2 Metadata timed out: " + str(err.__class__.__name__))
        tprint("Exception: Is this an EC2 instance? Is the AWS metadata endpoint blocked? (http://169.254.169.254/)")
        raise
    except Exception as e:
        tprint("Exception: caught exception " + str(e.__class__.__name__))
        raise        
def build_subnet_data() :
    global client,vpcId,mainRT
    global subnetDetails
    try:
        response = client.describe_subnets(
            Filters=[
                {
                    'Name': 'vpc-id','Values':  vpcId
                },]
        )
        for i in response['Subnets']:
            x={}
            x['SubnetId']=i['SubnetId']     
            subnetDetails[i['CidrBlock']]=x
    except Exception as e:
        tprint("Exception: caught exception " + str(e.__class__.__name__))
        raise           #build_vpc_rt_data()                

def build_vpc_rt_data() :
    global client,vpcId
    global subnetDetails
    global rtbResources    
    global mainRT,vpcRTTag
    filters=None
    try:
        if vpcRTTag == "ALL" :
            filters=[
                {
                    'Name': 'vpc-id','Values':  vpcId
                },]  
        else:
            data=vpcRTTag.split('=')
            if len(data) > 1:
                filters=[
                    {
                        'Name': 'vpc-id','Values':  vpcId
                    },
                    {
                        'Name': 'tag:'+data[0],'Values':  [data[1]]
                    }] 
            else:
                filters=[
                    {
                        'Name': 'vpc-id','Values':  vpcId
                    },
                    {
                        'Name': 'tag-key','Values':  [data[0]]
                    }]                         

        response = client.describe_route_tables(
            Filters=filters
        )
        for i in response['RouteTables']:
            if i['RouteTableId'] not in rtbResources.keys():
                tprint("Adding " + i['RouteTableId'] + " in pool of VPC RTs")
                rtbResources[i['RouteTableId']]=None
                foundExplicitAssociation=False
    except Exception as e:
        tprint("Exception: caught exception " + str(e.__class__.__name__))
        raise    
def build_publicPool_data() :
    global client,vpcId
    global publicPoolDetails
    try:
        response = client.describe_addresses()
        for i in response['Addresses']:
            cidr=i['PublicIp']
            if cidr.find('/') != -1: 
                x={}
                if 'AllocationId' in i.keys():
                    x['AllocationId']=i['AllocationId']
                if 'PublicIpv4Pool' in i.keys():
                    x['PublicIpv4Pool']=i['PublicIpv4Pool']          
                if 'AssociationId' in i.keys():
                    x['AssociationId']=i['AssociationId']                                      
                publicPoolDetails[i['PublicIp']]=x                            
    except Exception as e:
        tprint("Exception: caught exception " + str(e.__class__.__name__))
        raise           
                                     
def find_subnet_cidr(prefix,prefixLen):
    foundCidr=None
    inputCidr=prefix+"/"+str(prefixLen)
    global loopbackAdjustedCidr
    if inputCidr in loopbackAdjustedCidr.keys():
        foundCidr=loopbackAdjustedCidr[inputCidr]
    else:    
        if  prefixLen == 32:        
            for cidr in subnetDetails.keys():
                for addr in ipaddress.IPv4Network(cidr):
                    ##if its a subnet CIDR then overwrite with subnet CIDR
                    if ipaddress.IPv4Address(prefix) == addr:                       
                        foundCidr=cidr
                        break
                if foundCidr:
                    break     
        else:
            if inputCidr in subnetDetails.keys():
                foundCidr=inputCidr
        ## store to enable quick check        
        loopbackAdjustedCidr[inputCidr]=foundCidr           
    return foundCidr           

def find_eni(ip):
    global vpcId
    #Caching is not good
    #global eni_table
    #eni_id = eni_table.get(ip) 
    #if eni_id:
    #    return(eni_id)
    #else:
    response = client.describe_network_interfaces(
        Filters=[
            {
                'Name':'addresses.private-ip-address', 'Values': [ ip,]
            },
            {
                'Name':'vpc-id', 'Values': vpcId                    
            }
        ]
    )
    eni_id=""
    if response['NetworkInterfaces']:
        try:
            eni_id = response['NetworkInterfaces'][0]['NetworkInterfaceId']
#            logger1.debug("eni is",eni)
            #eni_table[ip]=eni_id
        except botocore.exceptions.ClientError as err:
            #errorcode = err.response['Error']['Code']
            tprint("error finding eni",err.response['Error']['Code'],ip)
#            logger1.warning("An exception occurred with finding the eni",errorcode)
    else:
        tprint("no matching network interface found for",ip)
    return(eni_id)
def add_route(eni,oldCidr,newCidr):
    procipv4 = []
    isLocalBreakoutHandling=False
    start = time.perf_counter() 
    if newCidr:
        cidr=newCidr
    else:
        cidr= oldCidr   
    if breakoutGWId != "none" or breakoutGWId != "None":
        if False == oldCidr.endswith("/32") :
            isLocalBreakoutHandling=add_n6_route(cidr, eni)               
    if False == isLocalBreakoutHandling :   
        for rtb in rtbResources:
            tprint("processing rtb: " + rtb)
            p = Process(target=add_route_new, args=(eni,cidr,rtb,rtbResources[rtb]))
            p.start()
            procipv4.append(p)                    
        # wait for  the parallel requests to complete execution and return 
        for p in procipv4:
            p.join(2)    
        end = time.perf_counter()        
        tprint(f"Finished All route tables for { cidr} {eni}  route Time is {end - start}")
def add_route_new(eni,cidr,rtb,bgp_resource) :   
    start = time.perf_counter() 
        ##try replacing first adding
    action="replace"
    try:   
        route = bgp_resource.Route(rtb,cidr)
        response = route.replace(
                NetworkInterfaceId=eni,
                )        
#        logger1.debug("added route for",cidr)
    except botocore.exceptions.ClientError as err:
        errorcode = err.response['Error']['Code']
        tprint("error while replace " + errorcode + ", will perfrom add" )       
        action="add"
        try: 
            route_table=bgp_resource.RouteTable(rtb)
            route = route_table.create_route(
                DestinationCidrBlock=cidr,
                NetworkInterfaceId=eni
            )        
        except botocore.exceptions.ClientError as err:
            errorcode = err.response['Error']['Code']            
            tprint("error while adding " + errorcode + ", skipping add" )
#            logger1.debug("replaced route",cidr)
    end = time.perf_counter()
    tprint(f"{rtb} {action} { cidr} {eni}  route Time is {end - start}")

def del_route(oldCidr,newCidr):
    procipv4 = []
    if newCidr:
        cidr=newCidr
    else:
        cidr= oldCidr       
    for rtb in rtbResources:
        tprint("processing rtb: " + rtb)
        p = Process(target=del_route_new, args=(cidr,rtb,rtbResources[rtb]))
        p.start()
        procipv4.append(p)                    
    # wait for  the parallel requests to complete execution and return 
    for p in procipv4:
        p.join(2)    
    tprint(f"Finished All route tables for { cidr}")
def del_route_new(cidr,rtb,bgp_resource):
    start = time.perf_counter()
#    print("deleting",cidr)
    #ec2 = boto3.resource('ec2',region_name=region)
    route = bgp_resource.Route(rtb,str(cidr))
    try:
        response = route.delete()
    except botocore.exceptions.ClientError as err:
        tprint("error deleting routes ",err.response['Error']['Code'],cidr)
    end = time.perf_counter()
    tprint(f"{rtb} delete  { cidr} route Time is {end - start}")
def add_n6_route(uePool, eni):
    result=0
    res="Pass"
    #if breakout == "local":
    if breakoutGWId.startswith('lgw') :
        result=add_n6_lgw(uePool, eni)
    elif breakoutGWId.startswith('igw'):     
        result=add_n6_igw(uePool, eni)   
    else:
        res="N/A"    
    if result != 0 :
        res="Fail"
    tprint("Destination:"+ uePool+" target:" + eni+ " result: " + res)        
    #if breakout == "remote": ##tgw,vgw etc , do nothing but add in the RT
    #    pass
    return result
def add_n6_lgw(uePool, eni):
    res=shell_run_cmd("export MODEL_PATH="+lgwRouteFile+ "; aws configure add-model --service-name ec2custom --service-model file://\$MODEL_PATH;aws ec2custom modify-local-gateway-route --region " + region + " --local-gateway-route-table-id " + breakoutGWId + "  --network-interface-id " + eni + " --destination-cidr-block " + uePool)
    return res[1] ##errorCode
def add_n6_igw(uePool, eni):
    if uePool in publicPoolDetails.keys():
        allocId=publicPoolDetails[uePool]['AllocationId']
        assocId=None
        assocENI=None
        try:
            response = client.describe_addresses(AllocationIds=[allocId])
            for i in response['Addresses']:
                if 'AssociationId' in i.keys():
                    assocId=i['AssociationId']     
                    assocENI=i['NetworkInterfaceId']           
        except botocore.exceptions.ClientError as err:
            tprint(f"error reading uePool {uePool} with {allocId}",err.response['Error']['Code'])
        cmd="aws ec2custom associate-address --region " + region + " --allow-reassociation --no-nat-enabled --network-interface-id " + eni + " --allocation-id  " + allocId   
        if assocId and assocENI!=eni:
            cmd="aws ec2custom disassociate-address --region " + region +  " --association-id  " + assocId + "; " + cmd
        res=shell_run_cmd("export MODEL_PATH="+prefixDelegateFile+ "; aws configure add-model --service-name ec2custom --service-model file://\$MODEL_PATH;" + cmd)
        return res[1] ##errorCode

def add_n6_others():
    pass  
def setSecIP(eni,secIP):
    tprint("Going to reassign iplist: " + secIP + " to ENI:" +eni )    

    response = client.assign_private_ip_addresses(
        AllowReassignment=True,
        NetworkInterfaceId=eni,
        PrivateIpAddresses = [secIP]    
        )
def run():
    global bgpUpdatesOngoing
    global cacheUpdating
    global floatingPeerSecondaryIPs
    flag = 1
    while(flag == 1):
        try:
            channel = grpc.insecure_channel('localhost:50051')
            stub = gobgp_pb2_grpc.GobgpApiStub(channel)
            flag = 0
 #          print("exiting the loop")
            continue
        except:
#           
            tprint("BGP APIs are down, retrying in 10 sec")
            time.sleep(10)
            continue
    responses = stub.MonitorTable(
        gobgp_pb2.MonitorTableRequest(
            table_type=gobgp_pb2.GLOBAL,
            family=gobgp_pb2.Family(afi=gobgp_pb2.Family.AFI_IP, safi=gobgp_pb2.Family.SAFI_UNICAST),
            name="",
            ),
        _TIMEOUT_SECONDS,
    )
    for count,response in enumerate(responses):
        #tprint(response)
        while cacheUpdating == True:
            tprint("VPC resources getting refreshed, waiting 0.2 seconds before continuing")
            Thread.sleep(0.2)
            continue
        bgpUpdatesOngoing == True
        start = time.perf_counter()
        table = MessageToDict(response)
        #tprint(table)
        isWithdraw = False
        try:
            isWithdraw = bool(table['path']['isWithdraw'])
        except:
            pass
        start = time.perf_counter()
        newCidr=None
        eni=None
        cidr=None
        nextHops=None
        prefix=None
        prefixLen=None
        try:
            ol = table['path']['pattrs']
            #tprint(ol)
            #list of ordered dict
            for item in ol:
                for key, value in item.items():
                    if key == "nextHops" :
                        nextHops=value[0] ##assumed that 1st Ip is least   
                        break
                    elif key== "nextHop":
                        nextHops=value     
                        break
            od = table['path']['nlri']
            #ordered dict
            for key, value in od.items():
                if key== "prefix":
                    prefix=value   
                if key== "prefixLen":
                    prefixLen=value                            
            cidr=prefix+"/"+str(prefixLen)
            eni = find_eni(nextHops)
            ###hard coding test
            #isWithdraw = True
            #eni="eni-02eb0cfdf8f57da2d"
            #prefix="1.1.1.0"
            #prefixLen="32"
            ###hard coding
            tprint("neighbor :" + table['path']['neighborIp'] + " received route -> destn: "+ cidr+ " nextHop:" + nextHops)
            if SubnetLoopbacks:
                newCidr=find_subnet_cidr(prefix,prefixLen)
            if newCidr:
                tprint(cidr + " belongs to VPC subnet CIDR: " + newCidr + " , updating the CDIR as traget")
                #cidr=subnetCidr           
            if eni:
                ## VPC EIP handling case, UPF NATS with private SecIP and IGW NATS with EIP, In this case UE POOL IP (destination IP) is same as NH IP
                if prefix in floatingPeerSecondaryIPs:
                    tprint(f"  {prefix} found in FloatingPeerSecondaryIPs configuration. It will be assigned as secondary IP for the {eni} ")
                    setSecIP(eni,prefix)
                else:    
                    if isWithdraw :
                        del_route(cidr,newCidr)
                    else :
                        add_route(eni,cidr,newCidr) 
            else:
                tprint(f"Couldnt find an ENI for adverized destn: {cidr} !!! skipping")                #        
        except (Exception) as e:
            tprint ("Error while processing the BGP received entries. Caught Exception :" + str(e))  
            tprint("skipping and moving on")         
        bgpUpdatesOngoing == False
        end = time.perf_counter()
        tprint(f"Complete update Time is {end - start}") 

def checkgobgpstatus():
    stdout, retCode=shell_run_cmd("pgrep -f gobgpd")
    return stdout, retCode
def checkstatus():
    stdout, retCode=shell_run_cmd("pgrep -f '" + sys.argv[0]+ " --oper start'")
    if retCode == 0:
        tprint("bgp speaker is running with pid: " + stdout.strip())
    else:
        tprint("bgp speaker is Not running !!")
    return stdout, retCode
def stop():
    stdout, retCode=checkstatus()
    if retCode == 0:
        terminategobgp()
        for pid in stdout.strip().split("\n"):
            shell_run_cmd("sudo kill -9 " + pid)            
        #timer.cancel()      
        exit(0)    
##run the go bgp
def rungobgp():
    os.system("sudo " + gobgpdFile + " -f " + gobgpConfFile + " &")    
    time.sleep(2)  
    stdout, retCode=shell_run_cmd("ps -eaf | grep -w gobgpd | grep -v grep | awk '{print $2}'")  
    if retCode == 0: 
        tprint("gobgp session running. with pid: " + str(stdout.split("\n")))   
    return retCode 
def terminategobgp():
    stdout, retCode=checkgobgpstatus()
    if retCode == 0:
        stdout, retCode=shell_run_cmd("x=$( ps -eaf | grep -w gobgpd | grep -v grep | awk '{print $2}'); sudo kill -9 ${x}")
        #time.sleep(1)

if __name__ == '__main__':
    setVars()
    global logger,file_handler
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s,%(msecs)d %(name)s %(levelname)s %(message)s')
    file_handler = logging.FileHandler(LogsDir+ datetime.datetime.now().strftime('mylogfile_%H_%M_%d_%m_%Y.log'))
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    parser = argparse.ArgumentParser(
            description='BGP Gateway to translate BGP updates to AWS VPC route table changed '
           )
    #parser.add_argument( '--breakout',  metavar='breakout_type', required=True, help='Options are local|remote|none')
    parser.add_argument( '--oper',  metavar='operation_type', required=True, help='Options are start|stop|status')
    parser.add_argument('--breakoutGWId', metavar='LGW RT id or IGW id or', default='none',required=False, help='lgw-rt-Id|igwId|none ex: lgw-rt=12345567890 or igw-1234567890 or none. none if the default value if no option given')
    parser.add_argument('--vpcRTTag', metavar='vpcRTouteTableTags', default='ALL',required=False, help='Options: ALL|BGPSpeaker=yes. This represents any tags as key=value pair to identify VPC route Tables,ex: BGPSpeaker=yes . ALL (or if no value provided) means select all route tables')
    parser.add_argument('--subnetLoopbacks', metavar='subnetBasedLoopbacks', default="False",required=False, help='true|false This indicates if Loopbacks are defined as subnets in VPC. Default value is false')    
    args = parser.parse_args()
    #tprint("Arguments --> breakout: " + args.breakout + " breakoutGWId: " + args.breakoutGWId + " vpcRTTag: " + args.vpcRTTag + " SubnetLoopbacks: " + args.SubnetLoopbacks)
    tprint("Arguments --> breakoutGWId: " + args.breakoutGWId + " vpcRTTag: " + args.vpcRTTag + " SubnetLoopbacks: " + args.subnetLoopbacks)
    runFlag=False
    try:
        operation=args.oper
        if operation == "start":
            runFlag=True
            get_info()
            init(args)
            stdout, retCode=checkgobgpstatus()
            if retCode == 0:
                if stdout != "":
                    tprint("gobgp session already running. No action taken, if you want to restart, then please do " + sys.argv[0] + " -- oper stop and then start again!!" )
                    sys.exit(1)
            else:        
                tprint("gobgp session not running. will be started now!!")                    
                ret=rungobgp()
                if ret == 0:
                    tprint("BGP process started! Waiting for neighbours to connect and advertize routes!!")
                    timer = RepeatTimer(300, build)
                    timer.start()    
                    while runFlag:
                        try:
                            run()
                        except (Exception) as e:  
                            x=""
                            for i in str(e).split("\n"):
                                if ("status" in i):
                                    x=x + i.strip() + " "
                            tprint("BGP session exception: " +x)
                            ## restart go bgp if it got killed somehow,else do nothing
                            stdout, retCode=checkgobgpstatus()
                            if retCode != 0:                            
                                rungobgp()
                            else:
                                time.sleep(2)
                            continue                
                else:
                    tprint("couldnt start BGP process. Exiting!!")
                        
        elif operation == "stop": 
            runFlag=False
            tprint("Stop Command received. Killing running sessions if any!!!")
            stop()
        elif operation == "status": 
            runFlag=False
            tprint("Status Command received.!!!")
            checkstatus()
            exit(0)
        else:
            tprint("Unknown oper Command received. No action taken!!!")
            exit(0)                
    except KeyboardInterrupt:
        runFlag=False
        stop()
