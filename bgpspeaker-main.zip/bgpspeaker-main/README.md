# BGP Speaker

***

## BGP Speaker  

Custom BGP Speaker is a simple, yet effective solution, managed by Global Telco Proserve, built on the design principles of the future VPC route Server service. BGP Speaker is not a vRouter. It acts as a BGP peer to the BGP speaking applications/routers, to achieve dynamic routing & fast failover.
BGP Speaker is an early implementation to influence CSPs and ISVs to get familiar with future VPC Route Server, and provide an early migration path from vRouters.  This functionality allows the application to advertise their routes (loopbacks/VIPs) over BGP. This feature is oftern requested by packet Core/user Plane functions like (UPF & SMF) for OAM,LI,N3,N4 and N6 services. 

### Benefits 
**Cost Optimization**
1. No vRouter licensing cost 
2. No 3rd party (cisco/juniper) professional services expertise/cost
3. t2.micro/t2.small ($0.01/hr) replaces m5(n).24xLarge/higher($3.6/hr-$4.5/hr), i.e. 400 times cheaper ec2 cost per vRouter

**Operational Excellence**

1. By eliminating need for virtual routers and custom scripting.
2. BGP capability, multi VRF support via X-ENI private feature
3. simple configuration, automation, subnetbased loopbacks, different SMF/UPF usecases as AIO (all in one)
4. Minimal IP planning/design consideration

**Performance**

1. No throughput or scale challenges, as it’s not in traffic path. 
2. Remove throughput bottlenecks of overlay tunnels introduced by virtual routers. 
3. Parallel route processing for multiple route tables for faster route convergence

**Resiliency**

1. Resiliency by autoscaling group and/or by Kubernetes replicas. 
2. Provides MultiAZ failover solution using floating IPs/VIP
3. Designed to quick failover

**Security**

1. Runs within VPC, and doesn’t egress/ingress to internet.
2. Works on least privileged security principles 

### Logical BGP speaker Deployment Model

![](images/bgp-speaker-deployment.jpg)

### Logical BGP speaker X-ENI based Deployment Model

![](images/BGP_Speaker_Deployment_X-ENI.jpg)

### Failover via BGP

![](images/bgp-speaker-failover.jpg)

### BGP speaker Best practices 
1. Plan 1 BGP speaker per SMF or UPF in the NF VPC. This helps in faster updates, and avoids race between multiple BGP speakers updating same Route Tables.
2. if you are using X-ENI based setup then deploy BGP speaker in each VPC where the XENI interface belongs.
3. If you have many VPC route tables, then you can select (using common Tags) only Route Tables which needs to reflect the routes.
4. This setup uses only 2 interfaces and use the same to use it for peering with your NFs (different NFs).
5. if you are using strict VRF separation in same VPC, and can't use same BGP speaker interfaces across multiple VRFs for peering, then deploy different BGP speakers per VRF (separate Route Tables). 
6. VPC Route tables separation (for above VRF case, or in general) can be achieved using subnet Tags. One BGP speaker can support, one subnet Tag (VPCRTTag in CloudFromation template)

## Deployment Architecture

BGP speaker is available in two deployment methods

1. [EKS based high available BGP speaker solution](#eks-based-high-available-bgp-speaker-deployment-procedure)
2. [EC2 based single AZ BGP speaker solution](#ec2-based-automated-deployment-procedure)

### EKS based high available BGP speaker Deployment procedure
![](images/BGP_Speaker_k8_deployment.jpg)

#### Installation

1. Please clone the Repo & build the image (replace xxxxxxxxxxxx with your account number)

```
git clone git@ssh.gitlab.aws.dev:proserv/bgpspeaker.git
cd bgpspeaker/
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin xxxxxxxxxxxx.dkr.ecr.us-east-1.amazonaws.com
aws ecr create-repository --repository-name bgpspeaker --region us-east-1
docker build -t xxxxxxxxxxxx.dkr.ecr.us-east-1.amazonaws.com/bgpspeaker:0.1 .
docker push xxxxxxxxxxxx.dkr.ecr.us-east-1.amazonaws.com/bgpspeaker:0.1
```
Use the [cloud formation template](k8-eks-bgps-nodegroup-multus.yaml) to deploy EKS nodegroups (multus based) for BGP speaker. This cloudFormation template creates 2 worker nodes, 1 each in separate AZ (based on the subnets chosen)
Refer the parameter in the ![multus git repo](https://github.com/aws-samples/eks-install-guide-for-multus/blob/main/cfn/templates/nodegroup/README.md).

2. Create the configMap for BGP speaker configuration.

```
kubectl apply -f k8/bgpspeaker-cm.yaml
```
Below are  details for the config params
```
AuthPassword:  Is the BGP authentication password. if you don’t want to use then use Default value as None.
BGPSpeakerAS:  This is the AS number of the BGP Speaker (use any number)
BGPSpeakerPrimaryENIIPAddress: is the virtual ip address (eth1) of the BGP speaker. if SubnetBasedLoopbacks is False, then you shall use non-vpc IP address,
                if True then use an IP address from the dummy vpc subnets.
BGPSpeakerSecondaryENIIPAddresses:  is the virtual ip address (eth2) of the BGP speaker. if SubnetBasedLoopbacks is False, then you shall use non-vpc IP address,
                if True then use an IP address from the dummy vpc subnets.
PeerAS: This is the AS number of BGP peer (UPF/SMF )
PrimaryENIPeers: This is comma separated list of IP addresses used for BGP peering on the primary interface(eth0) of the BGP speaker
SecondaryENIPeers: This is comma separated list of IP addresses used for BGP peering on the secondary interface(eth1) of the BGP speaker
SubnetBasedLoopbacks: true or false. True is the case when loopbacks are created as VPC subnets ( Comcast). It shall be set to false for all other usecases.
breakoutGWId:  is ID of internet enabler in local breakout case. Options are : none|lgw-rt-12345567890|igw-1234567890|none
        lgw-rt-12345567890: is the ID of the LGW RT (in case of outpost/frontier localZone) associated to VPC 
        igw-1234567890: is the ID of the IGW in the VPC
        none: when its not a local breakout case. means if its remote breakout or its SMF
vpcRTTag: TAG (format key=value or key) to identify the VPC RTs to be updated by BGP speaker. if no value then all VPC RTs in the applicable VPC.
connectRetry: BGP timer for connection retry 
holdTime: Min amount of time since the last successful keepalive message was detected, before removing the routes from the peer
keepaliveInterval: BGP time interval for periodic keep-alive heartbeat messages
EbgpMultiHop: Change to allow External BGP peerings to occur when they are more than 1 hop away

*custom features*

FloatingPeerSecondaryIPs: List of comma separated individual secondary IPs (Ex: 10.1.1.4,10.1.1.10). When you would like to move these IPs to the BGP advertized next Hop ENI.
                          Usually the case when using ELasticIp IP for N6 in UPF and not BYOIP UE pool. if you dont need, dont define it or set as None.
```
3. Create Multus network-attachment-definitions for BGP speaker configuration.
Usecase 1 SubnetBasedLoopbacks: False
you will use non-vpc IP address. in the sample example 100.1.1.2 and 100.1.1.6 are non-vpc floating IP addresses for BGP speaker pod
```
kubectl apply -f k8/multus-nad-1.yaml
kubectl apply -f k8/multus-nad-2.yaml
```
Usecase 2 SubnetBasedLoopbacks: True
you will use vpc IP address. create dummy subnets, you are going to use. in the sample example subnets created are 192.168.192.0/28 and 192.168.192.16/28. IP addresses
192.168.192.2 and 192.168.192.18 are vpc floating IP addresses for BGP speaker pod
```
kubectl apply -f k8/subnetbasedvip/multus-nad-sub-1.yaml 
kubectl apply -f k8/subnetbasedvip/multus-nad-sub-2.yaml 
```
<<<<<<< HEAD
4. Edit k8-bgpspeaker-deployment.yaml with the ECR URI of the docker image (step 1) and deploy the BGP speaker. you can 
=======
4. Edit k8-bgpspeaker-deployment.yaml with the ECR URI of the docker image (step 1) and deploy the BGP speaker. you can also edit the liveness and eadiness probe timers while debugging or as per your usecase.
>>>>>>> refs/remotes/origin/main

```
kubectl apply -f k8/k8-bgpspeaker-deployment.yaml
```
5. verify that BGP speaker pod is created and comes to ready state in few seconds, else check the logs and do the debug steps. you can also edit the liveness and readiness timers while debugging.
```
 k8 get po
NAME                                     READY   STATUS    RESTARTS   AGE
bgpspeaker-deployment-79585957f8-6qkxg   1/1     Running   0          47s
```      
If you face some issues then check logs or follow the [Debugging](#debugging)

```
kubectl logs bgpspeaker-deployment-xxxxxxxx
kubectl exec -it bgpspeaker-deployment-xxxxxxxx -- bash 
```

### EC2 based Automated Deployment procedure
1. Cloud formation provides all the configuration input for the BGP speaker.
2. S3 bucket will keep the installation artifacts and scripts
3. using that S3 bucket path, CloudFormation data will create the directory structure and install the python packages.
4. Helper scripts add the routes for the secondary interfaces and generate the gobgp configuration
5. BGPGW script, starts the gobgp process and uses the configuration provided in the Cloudfromation.
6. You can do the cloudformation update if there  are coonfiguration changes (Peer IP addresses, etc)

#### Installation

Please clone the Repo

```
git clone https://gitlab.aws.dev/proserv/bgpspeaker.git
```
Use the [cloud formation template](aws-cfn-bgps.yaml) to deploy BGP speaker. 
Sample configuration for the BGP speaker Cloud Formation template:
|Key    		 |Value|
| ------------- |:-------------:| 
|AuthPassword						|None	|
|BGPSpeakerAS						|65000	|				
|BGPSpeakerPrimaryENIIPAddress		|172.31.0.25|	
|BGPSpeakerSecondaryENIIPAddresses	|172.31.96.25|	
|BreakoutGWId						|none	|
|KeyName							|key	|
|NodeImageIdSSMParam				|/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2|
|NodeInstanceType					|t2.small|	
|PeerAS								|65001|
|PrimaryENIPeers					|192.168.1.150,192.168.1.151|
|PrimarySubnet						|subnet-5a0d6f3c|
|S3Bucket							|s3://raghvendra-bgp-speaker/install/|	
|SecondaryENIPeers					|192.168.1.204,192.168.1.205|	
|SecondarySubnet					|subnet-0a353a823a570e0d1|
|SubnetBasedLoopbacks				|false|
|VPCRTTag							||
|AMIId								||
|VpcId								|vpc-c015aabd|


Note:
```
AuthPassword:  Is the BGP authentication password. if you don’t want to use then use Default value as None.
BGPSpeakerAS:  This is the AS number of the BGP Speaker (use any number)
BGPSpeakerPrimaryENIIPAddress: is the primary interface ip address (eth0) of the BGP speaker.
PrimarySubnet: Subnet ID of the eth0 interface
BGPSpeakerSecondaryENIIPAddresses: is the secondary interface ip address (eth1) of the BGP speaker.
SecondarySubnet: Subnet ID of the eth1 interface
KeyName: SSH keypair name
NodeImageIdSSMParam: use Default value
PeerAS: This is the AS number of BGP peer (UPF/SMF )
PrimaryENIPeers: This is coomma separated list of IP addresses used for BGP peering on the primary interface(eth0) of the BGP speaker
SecondaryENIPeers: This is coomma separated list of IP addresses used for BGP peering on the secondary interface(eth1) of the BGP speaker
SubnetBasedLoopbacks: Takes value as true or false. This is the case when loopbacks are created as VPC subnets (Comcast). It shall be set to false for all other usecases.
S3Bucket: This is the path of s3 bucket where you copy the contents of the install/ folder provided in this git repo.
breakoutGWId:  is ID of internet enabler in local breakout case. Options are : none|lgw-rt-12345567890|igw-1234567890|none
        lgw-rt-12345567890: is the ID of the LGW RT (in case of outpost/frontier localZone) associated to VPC 
        igw-1234567890: is the ID of the IGW in the VPC
        none: when its not a local breakout case. means if its remote breakout or its SMF
vpcRTTag: is the TAG (format key=value or key) used to identify the VPC RTs to be updated (as GA VPC route server associates the RT to be updated). if no value then all VPC RTs in the applicable VPC.
AMIId: If you are using specific built AMIId (custom project or no internet access), else leave it blank. If blank then BGP speaker will install necessary ppackages from internet and S3 bucket.  
connectRetry: BGP timer for connection retry 
holdTime: Min amount of time since the last successful keepalive message was detected, before removing the routes from the peer
keepaliveInterval: BGP time interval for periodic keep-alive heartbeat messages
EbgpMultiHop: Change to allow External BGP peerings to occur when they are more than 1 hop away
FloatingPeerSecondaryIPs: List of comma separated individual secondary IPs (Ex: 10.1.1.4,10.1.1.10). When you would like to move these IPs to the BGP advertized next Hop ENI.
                          Usually the case when using ELasticIp IP for N6 in UPF and not BYOIP UE pool. if you dont need, dont define it or set as None.
```

## Debugging 

1. Ensure that following structure is maintained
```
$ ls -lrt
drwxr-xr-x 2 ec2-user ec2-user  44 Oct 10 19:03 logs
drwxr-xr-x 3 ec2-user ec2-user 218 Oct 10 19:03 bgp-gateway
drwxr-xr-x 2 ec2-user ec2-user  25 Oct 10 19:03 conf
drwxr-xr-x 2 ec2-user ec2-user  55 Oct 10 19:03 scr
drwxr-xr-x 2 ec2-user ec2-user  33 Oct 10 19:03 bin
```
2. check if gobgp processes are running
```
$ ps -eaf | grep -i bgp
root      3595     1  0 19:03 ?        00:00:00 sudo -u ec2-user python3 /home/ec2-user/bgp-gateway/bgpgw.py --oper start --breakoutGWId none --SubnetLoopbacks false
ec2-user  3600  3595  0 19:03 ?        00:00:00 python3 /home/ec2-user/bgp-gateway/bgpgw.py --oper start --breakoutGWId none --SubnetLoopbacks false
root      3617     1  0 19:03 ?        00:00:00 sudo /home/ec2-user/bin/gobgpd -f /home/ec2-user/conf/config.json
root      3623  3617  0 19:03 ?        00:00:00 /home/ec2-user/bin/gobgpd -f /home/ec2-user/conf/config.json
ec2-user  3667  3642  0 19:04 pts/0    00:00:00 grep --color=auto -i bgp
```
If pocesses are not running thne check following:

3. Only for EC2 based BGP speaker : check if rc-local is active or not. if failed then check its content and see what failed
```
[root@ip-172-31-0-25 ~]# systemctl status rc-local
● rc-local.service - /etc/rc.d/rc.local Compatibility
   Loaded: loaded (/usr/lib/systemd/system/rc-local.service; static; vendor preset: disabled)
   Active: active (running) since Wed 2022-10-12 18:39:51 UTC; 5h 16min ago
  Process: 3681 ExecStart=/etc/rc.d/rc.local start (code=exited, status=0/SUCCESS)
 Main PID: 3705 (sudo)
   CGroup: /system.slice/rc-local.service
   ....

[root@ip-172-31-0-25 ~]# cat  /etc/rc.d/rc.local
#!/bin/bash
# THIS FILE IS ADDED FOR COMPATIBILITY PURPOSES
#
# It is highly advisable to create own systemd services or udev rules
# to run scripts during boot instead of using this file.
#
# In contrast to previous versions due to parallel execution during boot
# this script will NOT be run after all other services.
#
# Please note that you must run 'chmod +x /etc/rc.d/rc.local' to ensure
# that this script will be executed during boot.

touch /var/lock/subsys/local
sudo -u ec2-user python3 /home/ec2-user/scr/gobgp-conf-builder.py --primaryIFIP 172.31.0.25 --bgpSpeakerAS 65000 --peerAS 65001 --primaryIFPeers 192.168.1.150,192.168.1.151 --secondaryIFIP 172.31.96.25 --secondaryIFPeers 192.168.1.204,192.168.1.205
sleep 1
sudo -u ec2-user cp /tmp/config.json /home/ec2-user/conf/config.json
sudo -u ec2-user python3 /home/ec2-user/scr/route-add.py --secondaryIFPeers 192.168.1.204,192.168.1.205
sudo -u ec2-user python3 /home/ec2-user/bgp-gateway/bgpgw.py --oper start --breakoutGWId none --SubnetLoopbacks true &   
```
4. Only for EC2 based BGP speaker : check cloud init output log file and see if anything failed
```
cat /var/log/cloud-init-output.log
```
5. Ensure that you have the desired routes for the seondary peers, and can ping the neighbor IPs
```
$ ip r
default via 172.31.0.1 dev eth0
default via 172.31.96.1 dev eth1 metric 10001
169.254.169.254 dev eth0
172.31.0.0/20 dev eth0 proto kernel scope link src 172.31.0.25
172.31.96.0/24 dev eth1 proto kernel scope link src 172.31.96.25
192.168.1.204 via 172.31.96.1 dev eth1
192.168.1.205 via 172.31.96.1 dev eth1
```
6. Ensure that port 179 connectivity shows established or in listen mode
```
sh-4.2$ netstat -an | grep 179
tcp        0      0 0.0.0.0:179             0.0.0.0:*               LISTEN
tcp6       0      0 :::179                  :::*                    LISTEN
sh-4.2$
```
7. check the log file  under /home/ec2-user/logs
8. you can use gobgp commands to check the RIB and neighbors
```
/home/ec2-user/bin/gobgp global rib
```
9. verify if the configuration is generated correctly (not many validations or checks are done in the MVP)


## Authors and acknowledgment
This version of BGP speaker has been built on the baseline PoC from Ammar(@latammar) in repo (https://gitlab.aws.dev/latammar/bgp-gateway). @latammar has also been very helpful in setting up a router to test & validate various usecases.

@jungy and @nebm had also been very helpful in providing feedback, validation and insiting on high standards to keep the solution practical and offer best possible experience to NFs and related call flows. 

## License
MIT-0 (AWS internal usage only)
