cd /app
x=""
if [ -n "${BGPSpeakerSecondaryENIIPAddresses}" ] ;
then
    x+=" --secondaryIFIP ${BGPSpeakerSecondaryENIIPAddresses}"
fi
if [ -n "${SecondaryENIPeers}" ] ;
then
    x+=" --secondaryIFPeers ${SecondaryENIPeers}"
fi
if [ "${AuthPassword}" != "None" ] ;
then
    x+=" --authPassword ${AuthPassword}"
fi
sleep 1
a="--oper start --breakoutGWId ${BreakoutGWId}"
y=""
if [ -n "${VPCRTTag}" ] ;  then
    y+=" --vpcRTTag ${VPCRTTag}"
fi
z=""
if [ -n "${SubnetBasedLoopbacks}" ] ;  then
    z+=" --subnetLoopbacks ${SubnetBasedLoopbacks}"
fi
args=""
if [ -n "${UseSBR}" ]; then
    args+=" --useSBR "
    args+="${UseSBR}"
else
    args+=" --useSBR False"
fi
if [ -n "${PrimaryENIPeers}" ]; then
    args+=" --intf1Peers "
    args+="${PrimaryENIPeers}"
fi
if [ -n "${SecondaryENIPeers}" ]; then
    args+=" --intf2Peers "
    args+="${SecondaryENIPeers}"
fi
echo "starting /app/scr/assign-vip.py with options: ${y} ${z} ${args} "
python3 -u /app/scr/assign-vip.py ${y} ${z} ${args} 
echo "starting  /app/scr/gobgp-conf-builder.py with options: --primaryIFIP ${BGPSpeakerPrimaryENIIPAddress} --bgpSpeakerAS ${BGPSpeakerAS} --peerAS ${PeerAS} --primaryIFPeers ${PrimaryENIPeers} ${x}"
python3 /app/scr/gobgp-conf-builder.py --primaryIFIP ${BGPSpeakerPrimaryENIIPAddress} --bgpSpeakerAS ${BGPSpeakerAS} --peerAS ${PeerAS} --primaryIFPeers ${PrimaryENIPeers} ${x}
cp /tmp/config.json /app/conf/config.json
echo "starting /app/bgp-gateway/bgpgw.py with options: $a $y $z"
python3 /app/bgp-gateway/bgpgw.py ${a} ${y} ${z}
